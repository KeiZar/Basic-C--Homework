﻿using System;

namespace _01.Sum_of_3_numbers
{
    class SumOfThreeNumbers
    {
        static void Main(string[] args)
        {
            double a = double.Parse(Console.ReadLine());
            double b = double.Parse(Console.ReadLine());
            double c = double.Parse(Console.ReadLine());

            Console.WriteLine(a + b + c);
        }
    }
}
