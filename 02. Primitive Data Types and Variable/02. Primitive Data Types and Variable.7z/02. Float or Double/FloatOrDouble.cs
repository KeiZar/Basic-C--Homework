﻿using System;
using System.CodeDom;

namespace _02.Float_or_Double
{
    class FloatOrDouble
    {
        static void Main(string[] args)
        {

            double a = 34.567839023;
            double b = 12.345;
            double c = 8923.1234857;
            double d = 3456.091;


            Console.WriteLine("Every number provided is a double\n{0}\n{1}\n{2}\n{3}", a, b, c, d);



        }
    }
}
