﻿using System;

namespace _01.Declare_Variables
{
    class DeclareVariables
    {
        static void Main(string[] args)
        {
            int a = 52130;

            short b = -115;

            int c = 4825932;

            byte d = 97;

            int e = -10000;

            Console.WriteLine("Integer:{0}\nShort: {1}\nInteger: {2}\nByte: {3}\nInteger: {4}", a,b,c,d,e);

        }
    }
}
