﻿using System;
using System.Globalization;
using System.Text;

namespace _08.Isosceles_Triangle
{
    class IsoscelesTriangle
    {
        static void Main(string[] args)
        {
            string copyrightSymbol = "©";

            Console.WriteLine("    " + copyrightSymbol);
            Console.WriteLine("   " + copyrightSymbol + " " + copyrightSymbol);
            Console.WriteLine("  " + copyrightSymbol + "   " + copyrightSymbol);
            Console.WriteLine(" " + copyrightSymbol + " " + copyrightSymbol+ " "+ copyrightSymbol + " " + copyrightSymbol);
            

        }
    }
}
