﻿using System;

namespace _03.Variable_in_Hexadecimal_Format
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0xFE;

            Console.WriteLine("Hex for \"{0}\" is 0xFE, and the Console prints it properly as {0}.", a);
        }
    }
}
