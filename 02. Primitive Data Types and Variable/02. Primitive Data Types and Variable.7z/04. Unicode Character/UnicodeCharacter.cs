﻿using System;

namespace _04.Unicode_Character
{
    class UnicodeCharacter
    {
        static void Main(string[] args)
        {

            char a = '\u002A';

            Console.WriteLine("The unicode syntax for \"{0}\" is \\u002A", a);
        }
    }
}
