﻿using System;

namespace _04.Print_first_and_last_name
{
    class FirstAndLast
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello my name is \nDimitar\nCekov!");
        }
    }
}
