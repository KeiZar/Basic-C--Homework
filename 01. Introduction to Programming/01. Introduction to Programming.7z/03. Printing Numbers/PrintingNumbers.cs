﻿using System;

namespace _03.Printing_Numbers
{
    class PrintingNumbers
    {
        static void Main(string[] args)
        {
            Console.WriteLine("1\n101\n1001");
        }
    }
}
