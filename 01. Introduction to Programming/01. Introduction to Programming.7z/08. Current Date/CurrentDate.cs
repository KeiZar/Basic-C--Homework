﻿using System;

namespace _08.Current_Date
{
    class CurrentDate
    {
        static void Main(string[] args)
        {
            Console.WriteLine(DateTime.Now);
        }
    }
}
